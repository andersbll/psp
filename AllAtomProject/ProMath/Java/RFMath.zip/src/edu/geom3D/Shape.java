package edu.geom3D;

import edu.math.Vector;

public interface Shape {
	public Vector getCenter();
}
