package edu.geom2D;

import java.util.List;

import edu.math.Vector2D;

public class Polygon {
	private List<Vector2D> points;
	
	public List<Vector2D> getPoints(){
		return points;
	}
}
