package edu.geom3D;

import java.util.List;

import edu.math.Vector;

public class BoundingVolumeManager {
	public static final int CAPSULE = 0;
	public static final int BOX = 1;
	public static Volume createBoundingVolume(List<Vector> points, int volumeType){
		switch(volumeType){
		case CAPSULE: return Capsule.createBoundingCapsule_CovarianceFit(points);
		case BOX: return Box.createBoundingBox_CovarianceFit(points);
		}
		throw new IllegalArgumentException("No such volume type implemented");
	}
	
	public static Volume createBoundingVolume(Volume v1, Volume v2, int volumeType){
		switch(volumeType){
		case CAPSULE: return Capsule.createBoundingCapsule_CovarianceFit((Capsule)v1, (Capsule)v2);
		}
		throw new IllegalArgumentException("No such volume type");
	}
	
	public static void extendVolume(Volume v, double rad){
		if(v instanceof Capsule){  ((Capsule)v).rad+=rad; return; }
		
		throw new IllegalArgumentException("No such volume type");
	}
}
