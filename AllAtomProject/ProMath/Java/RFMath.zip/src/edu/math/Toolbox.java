package edu.math;

import java.util.Random;

public class Toolbox {
	private static Random rand = new Random(); 
	
	/**
	 * Return a random number between (including) i1 and (not including) i2
	 */
	public static int randBetween(int i1, int i2){
		int max = Math.max(i1, i2);
		int min = Math.min(i1, i2);
		return (int)(rand.nextFloat()*(max-min)+min);
	}
	/**
	 * Return a random number between (including) f1 and (not including) f2
	 */
	public static float randBetween(float f1, float f2){
		float max = Math.max(f1, f2);
		float min = Math.min(f1, f2);
		return rand.nextFloat()*(max-min)+min;
	}
	
	
	/**
	 * Generate a random permutation between (including) 0 and 
	 * (not including) max
	 */
	public static int[] randPermutation(int max){
		int[] ret = new int[max];
		for(int i=0;i<max;i++){ ret[i] = i;}
		
		for(int i=0;i<max;i++){
			int sI = randBetween(0,max);
			int t = ret[sI];
			ret[sI] = ret[i];
			ret[i] = t;
		}
		return ret;
	}
	

	public static void seed(long s){
		rand = new Random(s);
	}
}
