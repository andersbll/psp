package edu.geom2D;

import java.util.List;

import edu.math.Vector2D;

public class VoronoiDiagram {
	/**Construct a voronoi diagram from the points*/
	public VoronoiDiagram(List<Vector2D> points, Polygon boundary){
		
	}
	
	
}
